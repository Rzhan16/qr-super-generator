import{c as y,j as t}from"./client-BBR4pSOT.js";import{c as d,r as h,Q as R,C as v,D as j}from"./qr-code-Dl0KEEOq.js";import{Q as q}from"./browser-CdqJbDhe.js";import"./_commonjsHelpers-Cpj98o6Y.js";/**
 * @license lucide-react v0.525.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const k=[["path",{d:"M15 3h6v6",key:"1q9fwt"}],["path",{d:"m21 3-7 7",key:"1l2asr"}],["path",{d:"m3 21 7-7",key:"tjx5ai"}],["path",{d:"M9 21H3v-6",key:"wtvkvv"}]],Q=d("maximize-2",k);/**
 * @license lucide-react v0.525.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const C=[["path",{d:"m14 10 7-7",key:"oa77jy"}],["path",{d:"M20 10h-6V4",key:"mjg0md"}],["path",{d:"m3 21 7-7",key:"tjx5ai"}],["path",{d:"M4 14h6v6",key:"rmj7iw"}]],N=d("minimize-2",C);/**
 * @license lucide-react v0.525.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const U=[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]],z=d("x",U);function D(){const[i,n]=h.useState({visible:!1,minimized:!1,qrDataUrl:null,currentUrl:"",isGenerating:!1,error:null});h.useEffect(()=>{let e=location.href;const o=new MutationObserver(()=>{const s=location.href;s!==e&&(e=s,p(s))});return o.observe(document.body,{childList:!0,subtree:!0}),chrome.runtime.onMessage.addListener(m),()=>{o.disconnect(),chrome.runtime.onMessage.removeListener(m)}},[]);const p=e=>{break;case"AUTO_GENERATE_QR":a(e.text||window.location.href,!1);break;case"SHOW_WIDGET":n(r=>({...r,visible:!0}));break;case"HIDE_WIDGET":n(r=>({...r,visible:!1}));break;case"TOGGLE_WIDGET":n(r=>({...r,visible:!r.visible}));break;default:console.debug("Unknown message type:",e.type)}},g=()=>{const e=window.location.href;(e.startsWith("http://")||e.startsWith("https://"))&&a(e,!0)},u=e=>{if(!(chrome!=null&&chrome.runtime)){console.debug("Chrome runtime not available for history storage");return}try{chrome.runtime.sendMessage({type:"STORE_QR_DATA",qrData:e}).catch(o=>{console.debug("History storage failed (non-critical):",(o==null?void 0:o.message)||"Unknown error")})}catch(o){console.debug("History storage error (non-critical):",o)}},a=async(e,o=!1)=>{let s=o;if(!o)try{s=(await chrome.storage.local.get(["showWidget"])).showWidget===!0}catch{console.debug("Could not check showWidget setting, defaulting to false"),s=!1}n(r=>({...r,isGenerating:!0,error:null,visible:s,currentUrl:e}));try{const r={width:200,margin:2,color:{dark:"#9333ea",light:"#ffffff"},errorCorrectionLevel:"M"},c=await q.toDataURL(e,r);n(x=>({...x,qrDataUrl:c,isGenerating:!1})),const b={text:e,dataUrl:c,timestamp:Date.now(),id:Date.now().toString(),type:e.startsWith("http")?"url":"text"};u(b)}catch(r){console.error("❌ QR generation failed:",r),n(c=>({...c,error:r.message,isGenerating:!1}))}},f=async()=>{if(i.qrDataUrl)try{const o=await(await fetch(i.qrDataUrl)).blob();await navigator.clipboard.write([new ClipboardItem({[o.type]:o})]),try{await navigator.clipboard.writeText(i.currentUrl),l("URL copied to clipboard!")}catch(o){console.error("❌ Failed to copy URL:",o)}}},w=()=>{if(i.qrDataUrl)try{const e=document.createElement("a");e.href=i.qrDataUrl,e.download=`qr-${window.location.hostname}-${Date.now()}.png`,document.body.appendChild(e),e.click(),document.body.removeChild(e),o.className="qr-notification",o.textContent=e,o.style.cssText=`
      position: fixed;
      top: 20px;
      right: 20px;
      background: #10b981;
      color: white;
      padding: 12px 16px;
      border-radius: 8px;
      z-index: 10001;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      font-size: 14px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
      animation: slideIn 0.3s ease-out;
    `,document.body.appendChild(o),setTimeout(()=>{o.style.animation="slideOut 0.3s ease-in",setTimeout(()=>{o.parentNode&&o.parentNode.removeChild(o)},300)},3e3)};return i.visible?t.jsxs("div",{className:`qr-widget ${i.minimized?"minimized":""}`,children:[t.jsxs("div",{className:"qr-widget-header",children:[t.jsxs("div",{className:"qr-widget-title",children:[t.jsx(R,{size:16}),t.jsx("span",{children:"QR Code"})]}),t.jsxs("div",{className:"qr-widget-controls",children:[t.jsx("button",{onClick:()=>n(e=>({...e,minimized:!e.minimized})),className:"qr-widget-btn",title:i.minimized?"Expand":"Minimize",children:i.minimized?t.jsx(Q,{size:14}):t.jsx(N,{size:14})}),t.jsx("button",{onClick:()=>n(e=>({...e,visible:!1})),className:"qr-widget-btn",title:"Close",children:t.jsx(z,{size:14})})]})]}),!i.minimized&&t.jsx("div",{className:"qr-widget-content",children:i.isGenerating?t.jsxs("div",{className:"qr-widget-loading",children:[t.jsx("div",{className:"qr-spinner"}),t.jsx("p",{children:"Generating QR code..."})]}):i.error?t.jsxs("div",{className:"qr-widget-error",children:[t.jsx("p",{children:"Failed to generate QR code"}),t.jsx("button",{onClick:()=>a(i.currentUrl,!0),className:"qr-retry-btn",children:"Retry"})]}):i.qrDataUrl?t.jsxs("div",{className:"qr-widget-display",children:[t.jsx("div",{className:"qr-image-container",children:t.jsx("img",{src:i.qrDataUrl,alt:"QR Code",className:"qr-image"})}),t.jsx("div",{className:"qr-url",children:t.jsx("p",{title:i.currentUrl,children:i.currentUrl.length>30?i.currentUrl.substring(0,30)+"...":i.currentUrl})}),t.jsxs("div",{className:"qr-actions",children:[t.jsxs("button",{onClick:f,className:"qr-action-btn",children:[t.jsx(v,{size:14}),"Copy"]}),t.jsxs("button",{onClick:w,className:"qr-action-btn",children:[t.jsx(j,{size:14}),"Save"]})]})]}):t.jsxs("div",{className:"qr-widget-empty",children:[t.jsx("p",{children:"No QR code generated"}),t.jsx("button",{onClick:g,className:"qr-generate-btn",children:"Generate QR"})]})})]}):null}function E(){if(window.location.protocol==="chrome-extension:"||window.location.protocol==="moz-extension:"||window.location.hostname==="")return;const i=document.createElement("div");i.id="qr-super-generator-widget",i.style.cssText=`
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 10000;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  `,document.readyState==="loading"?document.addEventListener("DOMContentLoaded",()=>{document.body.appendChild(i)}):document.body.appendChild(i),y.createRoot(i).render(t.jsx(D,{})),console.log("✅ QR widget initialized")}try{E()}catch(i){console.error("❌ Failed to initialize QR widget:",i)}
