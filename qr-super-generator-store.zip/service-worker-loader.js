// QR Super Generator Service Worker
try {
  importScripts('./assets/index.ts-BZQBSs0b.js');
} catch (error) {
  console.error('Service worker import failed:', error);
}
