// QR Super Generator Service Worker
try {
  importScripts('./assets/index.ts-BK0bAXIz.js');
} catch (error) {
  console.error('Service worker import failed:', error);
}
