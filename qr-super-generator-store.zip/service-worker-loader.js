// QR Super Generator Service Worker
try {
  importScripts('./assets/index.ts-B_pi7pkg.js');
} catch (error) {
  console.error('Service worker import failed:', error);
}
