// QR Super Generator Service Worker
try {
  importScripts('./assets/index.ts-B7Nj0Ool.js');
} catch (error) {
  console.error('Service worker import failed:', error);
}
